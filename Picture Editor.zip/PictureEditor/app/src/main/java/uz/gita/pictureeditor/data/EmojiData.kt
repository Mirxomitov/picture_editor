package uz.gita.pictureeditor.data

import androidx.annotation.DrawableRes

data class EmojiData (
    val id : Int,
    @DrawableRes val res : Int,
)